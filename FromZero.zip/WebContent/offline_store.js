
function Store1(){
	document.getElementById("img_td").src="images/offline_store-1.jpg";
	document.getElementById('name_td').value="알맹상점";
	document.getElementById("number_td").innerHTML="0507-1393-8913";
	document.getElementById("address_td").innerHTML="서울 마포구 합정동 월드컵로 49 한우마을 2층";
	}
function Store2(){
	document.getElementById("img_td").src="images/offline_store-2.jpg";
	document.getElementById('name_td').value="지구샵";
	document.getElementById("number_td").innerHTML="070-7640-4940";
	document.getElementById("address_td").innerHTML="서울 동작구 상도동 성대로1길 16";
}
function Store3(){
	document.getElementById("img_td").src="images/offline_store-3.jpg";
	document.getElementById("name_td").value="더피커";
	document.getElementById("number_td").innerHTML="070-4118-0710";
	document.getElementById("address_td").innerHTML="서울 성동구 왕십리로 115 헤이그라운드 9층";
}
function Store4(){
	document.getElementById("img_td").src="images/offline_store-4.jpg";
	document.getElementById("name_td").value="라마홈";
	document.getElementById("number_td").innerHTML="0507-1300-3042";
	document.getElementById("address_td").innerHTML="서울 종로구 자하문로 48 1층";
}
function Store5(){
	document.getElementById("img_td").src="images/offline_store-5.jpg";
	document.getElementById("name_td").value="송포어스";
	document.getElementById("number_td").innerHTML="070-8095-3534";
	document.getElementById("address_td").innerHTML="서울 강동구 풍성로35길 34 1층";
}
function Store6(){
	document.getElementById("img_td").src="images/offline_store-6.jpg";
	document.getElementById("name_td").value="디어얼스";
	document.getElementById("number_td").innerHTML="0507-1300-3388";
	document.getElementById("address_td").innerHTML="서울 서대문구 수색로 43 104호";
}

